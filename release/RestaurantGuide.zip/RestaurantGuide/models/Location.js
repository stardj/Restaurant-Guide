var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var Location = new Schema(
    {
        locate_longitude: {type: String, required: true, max: 100},
        locate_latitude: {type: String, required: true, max: 100},
        whatever: {type: String} //any other field
    }
);

var userCurrentLocationModel = mongoose.model('CurrentLocaltion', Location);

module.exports = userCurrentLocationModel;