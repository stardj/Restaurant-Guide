var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var UserInfo = new Schema(
    {
        useraccount: {type: String},
        userpassword: {type: String},
        confirmpw: {type: String},
        whatever: {type: String} //any other field
    }
);

var userInfoModel = mongoose.model('UserInfo', UserInfo);

module.exports = userInfoModel;